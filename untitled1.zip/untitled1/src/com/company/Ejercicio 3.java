package com.company;

class Main {
    public static void main (String []args){
        int resultado;
        resultado = A (10,15,30);

        System.out.println(resultado);
    }
public static int A (int a, int b,int c){
    return a+b+c;
    }
}

